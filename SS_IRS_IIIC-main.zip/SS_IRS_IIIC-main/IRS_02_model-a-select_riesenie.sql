-- S1. Vyp� cel� tabu�ku.
SELECT * FROM hry;

-- S2. Vyp� len n�zvy a ceny.
SELECT nazov, cena FROM hry;

-- S3. Vyp� hry ��nru FPS.
SELECT * FROM hry
WHERE zaner = 'FPS';

-- S4. Zora� hry od najdrah�ej.
SELECT * FROM hry
ORDER BY cena DESC;

-----------------------------------------------

-- F1. RPG hry vydan� po roku 2019. (AND)
SELECT * FROM hry
WHERE (zaner = 'RPG') AND (rok > 2019);

-- F2. Hry, ktor� s� zadarmo (cena 0).
SELECT * FROM hry
WHERE cena = 0;

-- F3. Hry s cenou od 10 do 30 � (vr�tane). (BETWEEN)
SELECT * FROM hry
WHERE cena BETWEEN 10 AND 30;

-- F4. Hry, ktor� s� RPG alebo FPS. (IN)
SELECT * FROM hry
WHERE zaner IN ('RPG', 'FPS');

-- F5. Hry, ktor�ch n�zov za��na na C. (LIKE 'C%')
SELECT * FROM hry
WHERE nazov LIKE 'C%';

-- F6. Hry drah�ie ako 40 � a z�rove� hodnoten� nad 9.
SELECT * FROM hry
WHERE (cena > 40) and (hodnotenie > 9);

-- F7. Hry aktualizovan� po 2026-08-01.
sELECt * FROM hry
WHERE aktualizovane > '2026-08-01';

-- F8. Zora� hry od najnov�ie aktualizovanej.
SELECT * FROM hry
ORDER by aktualizovane DESC;

